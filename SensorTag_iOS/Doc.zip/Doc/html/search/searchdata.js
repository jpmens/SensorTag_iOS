var indexSectionsWithContent =
{
  0: "abcdegimoprstvw",
  1: "abdmopsv",
  2: "abdmosv",
  3: "cdegiprsw",
  4: "bcdmpst",
  5: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "properties",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Properties",
  5: "Pages"
};

