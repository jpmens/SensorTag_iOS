var searchData=
[
  ['readvaluefromcharacteristic_3a',['readValueFromCharacteristic:',['../interfacebluetooth_handler.html#ac637163baf16867edce776ef15c2ac3c',1,'bluetoothHandler']]]
];
