var searchData=
[
  ['config',['config',['../interfaceble_generic_service.html#a5f11395fc9590f6ed64f4d55c60aa34a',1,'bleGenericService']]],
  ['connecttoidentifier',['connectToIdentifier',['../interfacebluetooth_handler.html#a0d3a0c77be0b2683e62ea8282e299744',1,'bluetoothHandler']]]
];
