var searchData=
[
  ['dataforenable_3a',['dataForEnable:',['../interfacesensor_functions.html#ab02236022d4d1ac2a7db981e901e26e4',1,'sensorFunctions']]],
  ['dataforenable_3aforservice_3a',['dataForEnable:forService:',['../interfacesensor_functions.html#a4bde24075441a50d5821c1d93a7ae093',1,'sensorFunctions']]],
  ['dataforperiod_3a',['dataForPeriod:',['../interfacesensor_functions.html#a6efa740d35582a43a6cbc80b3e20b04d',1,'sensorFunctions']]],
  ['dataupdate_3a',['dataUpdate:',['../interfaceble_generic_service.html#ae8b792f5fbbc0dd06fd5f6aa73c8502c',1,'bleGenericService']]],
  ['deconfigureservice',['deconfigureService',['../interfaceble_generic_service.html#a03c5b5fcc2490f0d83186a9e3c26274b',1,'bleGenericService']]],
  ['deviceready_3aperipheral_3a',['deviceReady:peripheral:',['../protocolbluetooth_handler_delegate-p.html#a94de95522697bb86ac33349be5d023bd',1,'bluetoothHandlerDelegate-p']]],
  ['didgetnotificaitononcharacteristic_3a',['didGetNotificaitonOnCharacteristic:',['../protocolbluetooth_handler_delegate-p.html#abcd20e643b729f1d5945a8fd51a73dce',1,'bluetoothHandlerDelegate-p']]],
  ['didreadcharacteristic_3a',['didReadCharacteristic:',['../protocolbluetooth_handler_delegate-p.html#abe9145cd9c0079f363a21e812abd9b7c',1,'bluetoothHandlerDelegate-p']]],
  ['didwritecharacteristic_3aerror_3a',['didWriteCharacteristic:error:',['../protocolbluetooth_handler_delegate-p.html#a36731f0ac5334f8f786e3acd2ee3c9a4',1,'bluetoothHandlerDelegate-p']]],
  ['disconnect',['disconnect',['../interface_m_q_t_t_i_b_m_quick_start.html#a960705de531a20389fb29928d43258c3',1,'MQTTIBMQuickStart']]],
  ['disconnectcurrentdevice',['disconnectCurrentDevice',['../interfacebluetooth_handler.html#a3fcf3ee51f227df71469289234535e92',1,'bluetoothHandler']]]
];
