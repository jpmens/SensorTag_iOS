var searchData=
[
  ['data',['data',['../interfaceble_generic_service.html#a1e20baf295faa5bff44371855b9e0d24',1,'bleGenericService']]],
  ['delegate',['delegate',['../interfacebluetooth_handler.html#a9058583c2d354abe0ef03d1ffbd6ec1d',1,'bluetoothHandler']]],
  ['devicelist',['deviceList',['../interfacebluetooth_handler.html#aaeffade47cc8f65cf0c8d4091a43049b',1,'bluetoothHandler']]]
];
