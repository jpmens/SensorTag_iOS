var searchData=
[
  ['init',['init',['../interfacebluetooth_handler.html#a0b0d6e1d6e33fbf4b406f93c62ac4bca',1,'bluetoothHandler']]],
  ['initwithservice_3a',['initWithService:',['../interfaceble_generic_service.html#a81a21ee235053adc4b890026e6db6f51',1,'bleGenericService']]],
  ['iscorrectservice_3a',['isCorrectService:',['../interfaceble_generic_service.html#a912e9def03778df881d519cd8bf06573',1,'bleGenericService']]]
];
