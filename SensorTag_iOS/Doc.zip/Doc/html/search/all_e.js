var searchData=
[
  ['writevalue_3atocharacteristic_3a',['writeValue:toCharacteristic:',['../interfacebluetooth_handler.html#aa7ba69c82452f9586c4df82178828078',1,'bluetoothHandler']]],
  ['wrotevalue_3aerror_3a',['wroteValue:error:',['../interfaceble_generic_service.html#ad1b915c3c057979212c7241f002efac5',1,'bleGenericService']]]
];
