var searchData=
[
  ['p',['p',['../interfacebluetooth_handler.html#a20bfcd30e8f5611f8b10cdc5af1cd897',1,'bluetoothHandler']]],
  ['period',['period',['../interfaceble_generic_service.html#a0da2ce557a4f24c280931cff5a78b9f3',1,'bleGenericService']]]
];
