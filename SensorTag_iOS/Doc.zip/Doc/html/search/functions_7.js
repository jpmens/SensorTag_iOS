var searchData=
[
  ['setnotifystateforcharacteristic_3aenable_3a',['setNotifyStateForCharacteristic:enable:',['../interfacebluetooth_handler.html#a5c713b4fddfb600d2c433e1ff2acfc57',1,'bluetoothHandler']]],
  ['sharedinstance',['sharedInstance',['../interfacebluetooth_handler.html#a70960ec9360beb35d03b0882dcb6c0f5',1,'bluetoothHandler::sharedInstance()'],['../interface_m_q_t_t_i_b_m_quick_start.html#a70960ec9360beb35d03b0882dcb6c0f5',1,'MQTTIBMQuickStart::sharedInstance()']]]
];
