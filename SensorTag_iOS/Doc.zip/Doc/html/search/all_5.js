var searchData=
[
  ['getclouddata',['getCloudData',['../interfaceble_generic_service.html#a87975328734fbc66883a95eae676b340',1,'bleGenericService']]],
  ['getviewforpresentation',['getViewForPresentation',['../interfaceble_generic_service.html#aa379688563aa166db68ccd63e86eba48',1,'bleGenericService']]]
];
