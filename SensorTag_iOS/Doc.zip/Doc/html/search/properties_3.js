var searchData=
[
  ['m',['m',['../interfacebluetooth_handler.html#a0a2496d7f88fdd47b9f121cd2002f49c',1,'bluetoothHandler']]]
];
